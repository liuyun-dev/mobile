define(
    function (require) {

        var comp = {};
        
        comp.slider= require("./component/slider");
        
        return comp;
    }
);