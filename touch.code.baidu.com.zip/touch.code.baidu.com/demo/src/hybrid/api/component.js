define(
    function (require) {

        var comp = {};
        
        //幻灯片组件
        comp.slider= require("./component/slider");
        
        return comp;
    }
);