define(

    /**
     * layerGroupApi，封装group api 事件。
     * 本api依赖于 crema css， index.html页面需要有 div.pages 容器。 
     * refresh 需要设定refresh的容易：page-content
     * @class Layer
     * @extends WebControl
     * @static
     * @inheritable
     */

    function (require) {
        var api = {};

        


        return api;
    }
);